Trabalho Final ICD

Grupo 1 - Forest Fires in Brazil

Helio Victor Flexa dos Santos - 2019006680
Matheus Prado Miranda - 2019007023
Kaio Lucas de Sá - 2019006850
Vitor de Oliveira Mafra - 2018046831

Apresentação do trabalho: https://www.youtube.com/watch?v=exMxEBNdZ8k

O notebook baixa todos os dados que utilizamos no trabalho de um repositório no Github, mas eles também podem ser encontrados aqui na pasta "data"

Importante: o relatório feito através do Streamlit se encontra na pasta "relatorio_streamlit". Para rodá-lo localmente, bastar baixar as bibliotecas necessarias usando o arquivo "requirements.txt". Em seguida, basta rodar o seguinte comando:

streamlit run relatorio_tp.py
